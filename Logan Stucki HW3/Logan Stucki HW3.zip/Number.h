class Number {
private:
    long number;
public:
    Number(long n);
    Number reverse();
    Number stripZeros();
    long get();
};
